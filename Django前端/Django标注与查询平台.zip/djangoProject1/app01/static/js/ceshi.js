// 获取按钮，身高，体重标签
var btn = document.getElementById('btn')
var text = document.getElementById('oritext')
var ent1=document.getElementById('ht1')
var ent2=document.getElementById('ht2')
var ent3=document.getElementById('ht3')
var ent4=document.getElementById('ht4')
var ent5=document.getElementById('ht5')


function findindex(text,entity) {
    for (i=0;i<text.length;i++){
        var substr=text.substring(i,Math.min(text.length,entity.length+i))
        if (substr==entity){
            return [i,entity.length+i]
        }
    }
     return [-1,-1]
}

//绑定点击事件(点击按钮时，再获取其中的值，如果在点击之前获取，会得到空值）
btn.onclick = function(){
    var ori_text = text.value
	var en1 = ent1.value
    var en2 = ent2.value
    var en3 = ent3.value
    var result = document.getElementById('result')
    var ens=[]
    var index=[]
    var dict={}
    dict['text']=ori_text
    dict['entites']=[]
    var inputens=[en1,en2, en3]

    for (let i of inputens){
        var ilen=i.length
        if (ilen>0){
        var temp=ens.unshift(i)/*添加数组元素*/
    }/*去除长度为0的实体词*/
    }
    for (let i of ens){
        var temp2=index.push(findindex(ori_text,i))
    }/*实体词在句中的索引位置*/

    for (j=0;j<ens.length;j++){
        var ind=index[j]
        dict['entites'].unshift([ens[j],ind[0],ind[1]])
    }

    result.innerHTML=JSON.stringify(dict )
}


