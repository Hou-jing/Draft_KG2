var btn = document.getElementById('btn')
var sent1 = document.getElementById('sent1')
var sent2=document.getElementById('sent2')

btn.onclick = function(){
    var s1 = sent1.value
	var s2 = sent2.value
    var result = document.getElementById('result')
    var dict={}
    dict['sent1']=s1
    dict['sent2']=s2
    var rrel=[]
    var truerel=['上下位','包含','其他']
    var form=document.getElementById('rel')
    for(var i=0; i<form.length; i ++){
        if(form[i].checked){
            rrel.unshift(i);
        }
    }
    ///for (i of form){
        //if (i.checked){
          //  rrel.unshift(i.value)
       /// }
    //}
    dict['rel']=[]
    for (item of rrel){
        dict['rel'].unshift(truerel[item])
    }
    result.innerHTML=JSON.stringify(dict)
}







