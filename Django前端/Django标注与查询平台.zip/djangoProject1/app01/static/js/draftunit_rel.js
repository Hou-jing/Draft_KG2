var btn1 = document.getElementById('reload')
var btn2 = document.getElementById('stabilize')
var draftkey=document.getElementById('draftkey')
var unitkey=document.getElementById('unitkey')
var cypernum=document.getElementById('cyphernum')
btn1.onclick=function () {
		var draftvalue = draftkey.value
		var unitvalue = unitkey.value
		var cyphernum_ = cyphernum.value
		console.log(draftvalue)
		console.log(unitvalue)
		var ncypher = "MATCH p=(n:`存储名`)-[r:`起草单位`]->(m:`机构`) where n.`中文名` contains '"+draftvalue+"' and m.`机构` contains '"+unitvalue+"' RETURN p LIMIT "+cyphernum_
		var result = document.getElementById('result')
        result.innerHTML=ncypher;
		if (ncypher.length > 3) {
			console.log('len>3')
			viz.renderWithCypher(ncypher);
		} else {

			console.log("reload");
			viz.reload();

		}

	}