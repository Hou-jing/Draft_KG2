
var btn1 = document.getElementById('reload')
var btn2 = document.getElementById('stabilize')
var cypher=document.getElementById('cypher')
var cyphernum=document.getElementById('cyphernum')

btn1.onclick=function () {
		var cyphervalue = cypher.value
		var cyphernum_ = cyphernum.value
		console.log(cyphervalue)
		var ncypher = "MATCH (n:`存储名`) where n.中文名 contains \"" +cyphervalue+ "\" RETURN n LIMIT "+cyphernum_
		var result = document.getElementById('result')
        result.innerHTML=ncypher;
		if (ncypher.length > 3) {
			console.log('len>3')
			viz.renderWithCypher(ncypher);
		} else {

			console.log("reload");
			viz.reload();

		}

	}


