from django.shortcuts import render,HttpResponse
from app01.models import UserInfo2,Term

# Create your views here.
#登录界面
def login(request):
    return render(request,'login.html')
def logininfo(request):
    #request.GET返回字典数据类型
    name=request.GET.get('name')
    password=request.GET.get('pwd')

    if not all([name,password]):
        return HttpResponse(
            '数据不完整'
        )
    try:
        obj1=UserInfo2.objects.create(name=name,password=password)#在数据库中存储该条数据
    except Exception as e:
        return HttpResponse('数据保存失败')
    return HttpResponse('Ok')

def find_head_index(text,ent):
    for i in range(len(text)):
        if text[i:i+len(ent)]==ent:
            return i,i+len(ent)
    return -1,-1


# Create your views here.
def term(request):
    return render(request,'领域词标注.html')
def terminfo(request):
    print(request.GET)
    text=request.GET.get('name')
    t1=request.GET.get('t1')
    t2 = request.GET.get('t2')
    t3=request.GET.get('t3')
    t4,t5,t6,t7,t8,t9,t10=request.GET.get('t4'),request.GET.get('t5'),request.GET.get('t6'),request.GET.get('t7'),request.GET.get('t8'),request.GET.get('t9'),request.GET.get('t10')
    ens=[t1,t2,t3,t4,t5,t6,t7,t8,t9,t10]
    d={}
    d['term']=[]
    for t in ens:
        if len(t)>0:
            d['term'].append([t,find_head_index(text,t)])
    d['text']=text

    try:
        obj=Term.objects.create(cont=d)
    except Exception as e:
       return HttpResponse('数据保存失败')
    return HttpResponse('OK')

'''#返回测试界面
def Test(request):
    return render(request, 'graph_ceshi.html')
#标准-起草单位之间关系建立测试界面,查询标准
def Draft_name(request):
    return render(request, 'draft_name.html')

#标准-起草单位之间关系建立测试界面,查询关系
def Draft_unit(request):
    return render(request, 'gragh_draftunit.html')'''


# 测试使用frameset建立标准查询网页
def TestFrame(request):
    return render(request, 'total_name.html')
def navig(request):
    return render(request,'navigation.html')
def query(request):
    return render(request,'query.html')
def footer(request):
    return render(request,'footer.html')

#测试使用frameset建立关系查询网页
def TestUnitFrame(request):
    return render(request, 'total_draftunit.html')

def queryunit(request):
    return render(request,'quertunit.html')


def annotation(request):
    return render(request,'annotation.html')