var cypher = "研究所";
var ncypher = "match (n:存储名) where n.中文名 contains "+cypher+"return n"
console.log(ncypher)