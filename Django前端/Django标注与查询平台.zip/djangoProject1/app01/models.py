from django.db import models


# Create your models here.
#登录界面账号
class UserInfo2(models.Model):
    id=models.AutoField(primary_key=True)
    name=models.CharField(max_length=32)
    password=models.CharField(max_length=32)

#术语存储界面
class Term(models.Model):
    id = models.AutoField(primary_key=True)
    cont= models.CharField(max_length=128)






