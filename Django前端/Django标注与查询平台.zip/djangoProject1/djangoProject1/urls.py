"""djangoProject1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,re_path
from app01 import views

urlpatterns = [
path('admin/', admin.site.urls),
    re_path('/login$',views.login),
    path('login/',views.login),
    path('logininfo/',views.logininfo),
    path('framename/',views.TestFrame),
    path('anno/',views.annotation),
    path('frameunit/',views.TestUnitFrame),
    re_path('/logininfo$',views.logininfo),
    re_path('/framename$',views.TestFrame),
    re_path('/anno$',views.annotation),
    re_path('/frameunit$',views.TestUnitFrame),
    re_path('/navigation$',views.navig),
    re_path('/footer$',views.footer),
    re_path('query$',views.query),
    re_path('queryunit$',views.queryunit),
    re_path('term$',views.term)

]




'''urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/',views.login),
    path('logininfo/',views.logininfo),
    path('framename/',views.TestFrame),
    path('framename/navigation',views.navig),
    path('framename/query',views.query),
    path('framename/footer',views.footer),
    path('frameunit/',views.TestUnitFrame),
    path('frameunit/navigation',views.navig),
    path('frameunit/queryunit',views.queryunit),

    path('term/',views.term),
    path('terminfo/',views.terminfo),
    path('anno/',views.annotation),
    path('anno/navigation',views.navig),
    path('anno/term',views.term),
    path('anno/footer',views.footer),


    #之后在做html之间的链接时，加入的url
    path('frameunit/query',views.queryunit),
    path('frameunit/footer',views.footer),
    path('frameunit/framename',views.TestFrame),
    path('framename/frameunit',views.TestUnitFrame),
path('frameunit/frameunit',views.TestUnitFrame),
path('framename/login',views.login),
path('frameunit/login',views.login),
path('frameunit/term',views.term),
path('framename/term',views.term),
    #正则表达有问题
re_path('.*/login',views.login),
re_path('.*/term',views.term),
re_path('.*/footer',views.footer),
re_path('/anno$',views.annotation)


]'''
